const con = require(`./db`);
const express =require(`express`);
const app = express();
const cors = require('cors');
const url = require("url");
const path = require('path');
const  port = 5000 || process.env.PORT;
const {secret} = require('./secret');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt')
const jwt  = require('jsonwebtoken');
const ONE_DAY  = 24*60*60;
const productImages = path.join(__dirname,"./assets","/Product");
const companyImages = path.join(__dirname,"./assets","/Company");
const publicFiles = path.join(__dirname,"../public"); 
const admin_route =require("./Routes/adminRoute")
const clientFiles = path.join(__dirname,'../Client');
const salt = 10;





app.use(express.urlencoded({ extended: false }));
app.use(express.json())
app.use(cors());
app.use(cookieParser())

app.use(express.static(clientFiles));
app.use(express.static(publicFiles))




app.set("views",clientFiles);
app.set('view engine','ejs');
app.use('/admin',admin_route)

const createToken = (id)=>{
  return jwt.sign({id},secret,{
    expiresIn:ONE_DAY
  })
}

app.use((req,res,next)=>{
  if(req.path === '/' || req.path === '/loginform' || req.path === '/signupform' || req.path === '/login' || req.path === '/signup' || req.path === '/company' || req.path === '/get_products' )return next();
  let user_id = req.cookies.user_id;
  let userToken = req.cookies.userToken;
  if(user_id && userToken)
  {

    jwt.verify(userToken,secret,(err,decodedToken)=>{
      if(err)
      {
        console.log(err)
        return res.redirect('/')
      }
      else{
        console.log(req.method)
        return next();
      }
     })
  }
  else{
    console.log("nrgjrf")
    res.redirect('/');
  }
})

app.use(express.static(productImages))
app.use(express.static(companyImages))



app.get('/',(req,res)=>{
  let user_id = req.cookies.user_id;
  let userToken = req.cookies.userToken;
  console.log("ngrk");
  if(user_id && userToken)
  {
    jwt.verify(userToken,secret,(err,decodedToken)=>{
      if(err)
      {
            res.render('login',{message:''});
      }
      else{
        return res.redirect('/home')
      }
     })
  }
  else{
    console.log("RG")
    res.render('login',{message:''});
  }
})


app.get('/signupform',(req,res)=>{
  res.render('signup',{message:''})
})


app.get('/loginform',(req,res)=>{
  res.render('login',{message:''})
})

app.post('/login',(req,res)=>{
  const email = req.body.email;
  const password = req.body.password;
  con.query("SELECT * from Users where `Email Id` = " + `'${email}'`,(err,results)=>{
    if(err)
    {
      res.render('login',{message:"Server Not Responding Try Again !!"});
    }
    else{
     bcrypt.compare(req.body.password,results[0].password,(err,result)=>{
      if(err)
      {
        res.render('login',{message:"Server Not Responding Try Again !!"});
      }
      else if(result == false)
      {
        res.render('login',{message:"Wrong Password!!"});
      }
      else if(result == true)
      {
        console.log("rgnrngrk",results[0])
        if(results[0].Status === 'APPROVED')
        {
          console.log(results)
          const token = createToken(results[0]['Email Id'])
          res.cookie('userToken',token)//,{httpOnly:true,maxAge : 2*ONE_DAY * 1000});
          res.cookie('user_id',results[0].User_Id)//,{maxAge : 2*ONE_DAY * 1000});
          res.redirect('/home');
        }
        else{
          res.render('login',{message:"You are not approved by the Admin !!"}); 
        }
      }
     })
    }
  })
})

app.post("/signup", (req, res) => {
  const q = req.body;
  let sql =  " SELECT * FROM Users WHERE `Email Id`  = " + `'${q.email}'`;
  con.query(sql, (err, result)=>
  {
    console.log(result)
    if (err) {
      console.log(err);
      res.render('signup',{message:"Server Not Responding Try Again !!"});
    } 
    else if (result.length >= 1) {
      console.log(err);

      res.render('signup',{ message: "User already exist with this email" });
    } 
    else {
      bcrypt.hash(q.password,salt,function(err,hash){
        if(err)
        {
          console.log(err);

          res.render('signup',{message:"Server Not Responding Try Again !!"});
        }
        else{
          const sql="INSERT INTO `Users`( `Name`, `Email Id`, `password`, `Address`, `City`, `State`, `Pin Code`, `Contact Number`, `Birth Date`, `Status`) VALUES ('"+q.name+"','"+q.email+"','"+hash+"','"+ q.address +"','"+q.city+"','"+q.state+"','"+q.pincode+"','"+q.phone+"','"+q.date+"','PENDING')";
          // const sql = ` INSERT INTO 'Users'('Name', "Email Id", password, Address, City, State, "Pin Code","Contact Number", "Birth Date", 'Status')  VALUES('${q.name}','${q.email}','${hash}','${q.address}','${q.city}','${q.state}','${q.pincode}','${q.phone}','${q.date}','PENDING')`;
          con.query(sql, (err, result) => {
            if (err) {
              console.log(err);
              res.render('signup',{message:"Server Not Responding Try Again !!"});

            } else {
                res.render('signup',{message:'Signup Successfull!! Wait for admin approval'});
            }
          });
        }
      })

    }
  })
})


app.get("/home", (req, res) => {
  console.log("Rgrg")
  let q_str =
    "select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='Device' and (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4 ; "+
    "select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='Liquides' and (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4 ;"+
    "select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='Accessories' and (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4 ;"+
    "select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='Disposables' and (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4 ;"+
    "select * from Companies";
  con.query(q_str, [1, 2, 3, 4,5], function (err, result) {
    if (err){
      console.log(err)
      res.send('THERE IS SOME ERROR');
    }
    res.render("index", {
      main: "Home",
      devices: result[0],
      liquides: result[1],
      accessories: result[2],
      desposables: result[3],
      companies:result[4],
    });
  });
});


app.get("/cart",(req,res)=>{
  res.render("cart",{main:"Cart"});
})


app.get("/allporducts", (req, res) => {
  var q = url.parse(req.url, true);
  if (q.query.main == q.query.page) {
    let q_str ="select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='" + q.query.main + "' GROUP by Products.product_id Order by Products.product_id ; "+
               "SELECT product_id,SUM(product_qty) as total FROM Types where product_id in(select product_id from Products where product_main_cat='"+q.query.main+"') GROUP BY product_id ORDER by product_id";
    con.query(q_str,[1,2], function (err, result) {
      if (err) {
         console.log(err)
      }
      res.render("allproducts", {
        main: q.query.main,
        page: q.query.page,
        details: result[0],
        total_qty: result[1]
      });
    });
  } else {
    let q_str ="select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.product_main_cat='" + q.query.main +"' and Products.product_sub_cat='" +q.query.page +"' GROUP by Products.product_id Order by Products.product_id ; "+
               "SELECT product_id,SUM(product_qty) as total FROM Types where product_id in(select product_id from Products where product_main_cat='"+q.query.main+"' and product_sub_cat='"+q.query.page+"') GROUP BY product_id ORDER by product_id";
    con.query(q_str,[1,2], function (err, result) {
      console.log("all products",q_str);
      if (err){
      }
      res.render("allproducts", {
        main: q.query.main,
        page: q.query.page,
        details: result[0],
        total_qty:result[1]
      });
    });
  }
});

app.get("/allProductsOfCompany", (req, res) => {
  var q = url.parse(req.url, true);
  let q_str ="select * from Products INNER join Product_Images where Products.product_id=Product_Images.product_id and Products.company_name='" + q.query.company_name+"' GROUP by Products.product_id Order by Products.product_id;"+
  "SELECT product_id,SUM(product_qty) as total FROM Types where product_id in(select product_id from Products where Products.company_name='" + q.query.company_name + "') GROUP BY product_id ORDER by product_id";
  con.query(q_str, function (err, result) {
    if (err) {
        console.log(err)
      }
      res.render("allproducts", {
        main: 'Companies',
        page:q.query.company_name,
        details: result[0],
        total_qty: result[1]

      });
    });
  
});



app.get("/productDetails", (req, res) => {
  var q = url.parse(req.url, true);
  if (q.query.main == q.query.page) {
    let q_str ="select * from Products inner join Product_Images where Products.product_id=Product_images.product_id and Product_id='" + q.query.product_id + "' Group by Products.product_id ; " +
               "select * from Product_images where product_id='" + q.query.product_id + "' ; " +
               "select * from Types where product_id='" + q.query.product_id + "' ; " +
               "SELECT * from Products inner join Product_Images where Products.product_id=Product_Images.product_id and Products.company_name=(SELECT company_name from Products where product_id='"+q.query.product_id+"') and Products.product_id !='"+q.query.product_id+"' AND (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4"
    con.query(q_str, [1, 2, 3, 4], function (err, result) {
      if (err) {
      }
      console.log(result[3])
      res.render("product", {
      
        main: q.query.main,
        page: q.query.page,
        details: result[0],
        images: result[1],
        varaiety: result[2],
        others: result[3],
      });
    });
  } else {
    let q_str ="select * from Products inner join Product_Images where Products.product_id=Product_Images.product_id and Products.product_id='" + q.query.product_id + "' Group by Products.product_id ; " +
               "select * from Product_Images where product_id='" + q.query.product_id + "' ; " +
               "select * from Types where product_id='" + q.query.product_id + "' ; " +
               "SELECT * from Products inner join Product_Images where Products.product_id=Product_Images.product_id and Products.company_name=(SELECT company_name from Products where product_id='"+q.query.product_id+"') and Products.product_id !='"+q.query.product_id+"' AND (SELECT SUM(product_qty) from Types where product_id=Products.product_id)>0 GROUP by Products.product_id Order by Products.product_id LIMIT 4"
    con.query(q_str, [1, 2, 3, 4], function (err, result) {
      console.log(q_str);
      if (err){
      }
      res.render("product", {
        main: q.query.main,
        page: q.query.page,
        details: result[0],
        images: result[1],
        varaiety: result[2],
        others: result[3],
      });
    });
  }
});


app.post("/search", (req, res) => {
  q_str="select * from Products inner join Product_Images where Products.product_id=Product_Images.product_id and ( Products.company_name LIKE'%" + req.body.search + "%' or Products.product_name LIKE'%" + req.body.search + "%' ) Group by Products.product_id order by Products.product_id ; "+
        "SELECT product_id,SUM(product_qty) as total FROM Types where product_id in(select product_id from Products where company_name LIKE'%" + req.body.search + "%' or product_name LIKE'%" + req.body.search + "%') GROUP BY product_id ORDER by product_id";

  con.query(q_str,[1,2], function (err, result) {
    if (err) {
      console.log("search",q_str);
    }
    res.render("allproducts", {
      main: "Search",
      page: "Search Result",
      details: result[0],
      total_qty:result[1]
    });
  });
});

app.post('/put_order',(req,res)=>{
  console.log(req.body)
  const user_id = req.body.user_id;
  const total_price = req.body.total_price;
  con.beginTransaction();
  con.query(`INSERT INTO Orders (User_Id,total_price) values ('${user_id}','${total_price}')`,(err,result)=>{
    if(err)
    {
      console.log(err)
      res.send({message:'Error'})
    }
    else{
      let order_id = result.insertId;
      let values = []
      for(product of req.body.products)
      {
         values.push([order_id,...Object.values(product)])
      }
      con.query(`INSERT INTO Order_Details (Order_id, product_id, product_type, product_type_des, ordered_product_qty, ordered_product_total_price) values ?`,[values],(err,result)=>{
        if(err)
        {
          console.log(err)
          con.rollback(function(){
            res.send({message:'Error'})
          })
        }
        else{
           console.log("success")
           con.commit();
           res.send({message:'Success'})
        }
      })
    }
  })
})

app.get('/signout',(req,res)=>{
  res.clearCookie('userToken');
  res.clearCookie('user_id');
  res.redirect('/');
})

app.get('/company',(req,res)=>{
    console.log("bjfjgntjb")
    const sql = ` SELECT * FROM Companies `;    
    con.query(sql,(err,result)=>{
        if(err) console.log(err);
        else{
            res.send(result);
        }
    });   
});

app.post('/get_products/:main_cat/:sub_cat',(req,res)=>{
  let finalResult={};
  con.query('SELECT * from Products NATURAL JOIN Types',(err,result)=>{
    if(err)
    {
      res.send({message:'Error'})
    }
    else{
      if (req.params.main_cat) {
        result = result.filter((value, index, array) => {
          if (value.product_main_cat === req.params.main_cat)
            return value;
        });
      }
      if(req.params.sub_cat){
        result = result.filter((value, index, array) => {
          if (value.product_sub_cat === req.params.sub_cat)
            return value;
        });
      }
      finalResult['types'] = result;
      let diffrentIds = []
      for (i of result)
      {
        if(diffrentIds.includes(i.product_id) === false)
        {
          diffrentIds.push(i.product_id)
        }
      }
      con.query('SELECT * FROM Products NATURAL JOIN Product_Images',(err,result)=>
      {
        if(err)
        {
          res.send({message:'Error'})
        }
        else{
          result = result.filter((value, index, array) => {
            if (diffrentIds.includes(value.product_id))
              return value;
          });
          finalResult['images'] = result;
          res.send(finalResult)
        }
      })
    }
  })  
})






app.listen(port,(err)=>{
    if(err)
        console.log(err);
    else 
        console.log(`server is started on ${port} port..`);
});




