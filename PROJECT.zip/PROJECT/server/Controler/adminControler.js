const con = require(`../db`);
const path = require('path')
const static = path.join(__dirname, "../../Admin")
const multer = require('multer');
const fs = require('fs');
const jwt  = require('jsonwebtoken');
const {secret} = require('../secret');
const company_path = path.join(__dirname, '../assets/Company');
const product_path = path.join(__dirname, '../assets/Product');
const ONE_DAY  = 24*60*60;
const bcrypt = require('bcrypt')



const createToken = (id)=>{
  return jwt.sign({id},secret,{
    expiresIn:ONE_DAY
  })
}


// ARRAY FOR IMAGES 
var uploaded_product_files = []
var uploaded_compnay_file = [];



//HELPER FUNCTION TO DELETE IMAGES
function deleteUploadedFile(files, ref_path) {
  for (let i of files) {
    console.log(i)
    fs.unlink(ref_path + `/${i}`, function (err) {
      if (err) console.log(err);
      else console.log("deleted")
    });
  }
}

// HELPER FUNCTIONS TO UDATE IN LOOP 

function HelperUpdate(details, i) {
  return new Promise((resolve, reject) => {
    con.query(`UPDATE Types SET product_qty = product_qty - ${details[i]['ordered_product_qty']} where product_id = '${details[i]['product_id']}' and product_type = '${details[i]['product_type']}'  and product_type_des = '${details[i]['product_type_des']}' `, (err, result) => {
      if (err) {
        con.rollback(function () {
        })
        reject('Error')

      }
      else {
        resolve('Success')
      }
    })
  });
}

//HELPER FUNCTION STOCK

function HelperUpdateStock(product_id, product_type, product_type_des, product_qty) {
  return new Promise((resolve, reject) => {
    con.query(`UPDATE Types SET product_qty = ${product_qty} where product_id = '${product_id}' and product_type = '${product_type}'  and product_type_des = '${product_type_des}' `, (err, result) => {
      if (err) {
        con.rollback(function () {
        })
        reject('Error')
      }
      else {
        resolve('Success')
      }
    })
  });
}



//DEFINES STORAGE  FOR IMAGES 

const CompanyStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, company_path);
  },
  filename: function (req, file, cb) {
    const company_name = req.body.company_name;
    const filename = company_name + "_" + Date.now() + path.extname(file.originalname);
    uploaded_compnay_file.push(filename);
    cb(null, filename);
  }
});
const uploadCompany = multer({ storage: CompanyStorage }).single('company_logo');




const ProductStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, product_path);
  },
  filename: function (req, file, cb) {
    const filename = req.body.company_name + "_" + req.body.product_name + "_" + Date.now() + "_" + path.parse(file.originalname).name + path.extname(file.originalname);
    uploaded_product_files.push(filename);
    cb(null, filename)
  }
});
const uploadProduct = multer({ storage: ProductStorage }).any('product_images');




//ROUTES CONTROLERS 

const SignIn = async (req, res) => {
  console.log("USER LOGIN")
  const email = req.body.email;
  const password = req.body.password;
  console.log(email, password)
  con.query(`SELECT * FROM Admin where email = '${email}'`, (err, results) => {
    if (err){
      console.log(err)
    }
    else {
      bcrypt.compare(password,results[0].Password,(err,result)=>{
        if(err)
        {
          console.log(err)
        }
        else if(result == false)
        {
          res.send({ message: "Wrong" });
        }
        else if(result == true)
        {
          const token = createToken(results[0].Email)
          res.cookie('adminToken',token,{httpOnly:true,maxAge : ONE_DAY * 1000});
          res.send({ message: "Success" });
        }
       })
    }
  });
}


const SignInPage = async (req, res) => {
  console.log("SEND SIGNIN PAGE")
  res.sendFile(static + "/login.html")
}


const AddCompany = async (req, res) => {
  console.log("ADD COMPANY")
  uploaded_compnay_file = []
  uploadCompany(req, res, (err) => {
    const company_name = req.body.company_name;
    if (err) {
      deleteUploadedFile(uploaded_compnay_file, company_path);
      res.send({ message: 'Error' })
    }
    else {
      con.query(`SELECT * FROM Companies where company_name = '${company_name}'`, (err, result) => {
        if (err) {
          deleteUploadedFile(uploaded_compnay_file, company_path);
          console.log(err)
          res.send({ message: "Error" })
        }
        else if (result.length >= 1) {
          deleteUploadedFile(uploaded_compnay_file, company_path);
          res.send({ message: "Duplicate" })
        }
        else if (result.length == 0) {
          con.query(`INSERT INTO Companies(company_name,company_logo_path) values ('${company_name}','${uploaded_compnay_file}')`, (err, result) => {
            if (err) {
              deleteUploadedFile(uploaded_compnay_file, company_path);
              console.log(err)
              con.rollback(function () {
                res.send({ message: 'Error' })
              })
            }
            else {
              con.commit()
              res.send({ message: 'Success' })
            }
          })
        }
      })
    }
  })
}


const AddProduct = async (req, res) => {
  uploaded_product_files = [];
  console.log("ADD PRODUCT")
  console.log(req.body)

  uploadProduct(req, res, (err) => {
    if (err) {
      deleteUploadedFile(uploaded_product_files, product_path);
      res.send({ message: "Error" })
    }
    const company_name = req.body.company_name;
    const product_name = req.body.product_name;
    const product_type = req.body.product_type;
    const product_price = req.body.product_price;
    const product_main_cat = req.body.product_main_cat;
    const product_sub_cat = req.body.product_sub_cat ? req.body.product_sub_cat : 'None';
    const product_des = req.body.product_description;
    const product_total_type = req.body.product_total_type;
    const product_types = req.body.product_types;
    const product_types_qty = req.body.product_types_qty;
    const product_qty = req.body.product_qty;
    con.query(`SELECT * FROM Products where company_name = '${company_name}' and product_name = '${product_name}'`, (err, result) => {
      if (err) {
        deleteUploadedFile(uploaded_product_files, product_path);
        console.log(err)
        res.send({ message: "Error" })
      }
      else if (result.length >= 1) {
        deleteUploadedFile(uploaded_product_files, product_path);
        res.send({ message: "Duplicate" })
      }
      else if (result.length == 0) {
        con.beginTransaction(function (err) {
          if (err) {
            deleteUploadedFile(uploaded_product_files, product_path);
            console.log(err)
            con.rollback(function () {
              res.send({ message: 'Error' })
            })
          }
          con.query(`insert into Products(company_name,product_name,product_type,product_price,product_main_cat,product_sub_cat,product_description) values('${company_name}','${product_name}','${product_type}','${product_price}','${product_main_cat}','${product_sub_cat}','${product_des}')`, (err, result) => {
            if (err) {
              deleteUploadedFile(uploaded_product_files, product_path);
              console.log(err)
              con.rollback(function () {
                res.send({ message: 'Error' })
              })
            }
            else {
              let id = result.insertId;
              let values = []
              if (product_type === "None") {
                values.push([id, product_type, "None", product_qty])
              }
              else {
                for (let i = 0; i < product_total_type; i++) {

                  values.push([id, product_type, product_types[i], product_types_qty[i]])
                }
              }
              con.query(`INSERT INTO Types(product_id,product_type,product_type_des,product_qty) values ?`, [values], (err, result) => {
                if (err) {
                  deleteUploadedFile(uploaded_product_files, product_path);
                  console.log(err)
                  con.rollback(function () {
                    res.send({ message: 'Error' })
                  })
                }
                else {
                  let values = []
                  for (let i = 0; i < uploaded_product_files.length; i++) {
                    values.push([id, encodeURIComponent(uploaded_product_files[i])]);
                  }
                  con.query(`INSERT INTO Product_Images(product_id,img) values ?`, [values], (err, result) => {
                    if (err) {
                      deleteUploadedFile(uploaded_product_files, product_path);
                      console.log(err)
                      con.rollback(function () {
                        res.send({ message: 'Error' })
                      })
                    }
                    else {
                      con.commit()
                      res.send({ message: 'Success' })
                    }
                  })
                }
              })
            }
          })

        })
      }
    })

  })
}


const GetUsers = async (req, res) => {
  console.log("GET USERS")
  const q = req.body;
  const sql = "SELECT `User_Id`,`Name`,`Email Id`,`Address`,`City`,`State`,`Pin Code`,`Contact Number`,`Birth Date`,`Status`,`time_stamp` FROM Users Order By `time_stamp` Desc";
  console.log(req.params)
  con.query(sql, (err, result) => {
    if (err) console.log(err);
    if (req.params.flag === 'approved') {
      result = result.filter((value, index, array) => {
        if (value.Status === 'APPROVED')
          return value;
      });
    }

    else if (req.params.flag === 'pending') {
      result = result.filter((value, index, array) => {
        if (value.Status === 'PENDING')
          return value;
      });
    }



    else if (req.params.flag === 'rejected') {
      result = result.filter((value, index, array) => {
        if (value.Status === 'REJECTED')
          return value;
      });
    }


    return res.send(result);
  });
}


const ChangeUserRequest = async (req, res) => {
  console.log("User Status Changed")
  con.query(`UPDATE Users SET Status = '${req.params.new_status}' where User_Id = '${req.params.user_id}' `, (err, result) => {
    if (err) {
      console.log(err)
      res.send({ message: "Error" })
    }
    else {
      res.send({ message: "Success" })
    }
  })
}


const OrderDetials = async (req, res) => {
  console.log("Order Details")
  let sql = "SELECT A.User_Id,A.Name,A.`Email Id`,A.Address,A.City,A.State,A.`Pin Code`,A.`Contact Number`,A.`Birth Date`,B.Order_id,B.date,B.Order_Status,B.total_price,C.product_id,C.product_type,C.product_type_des,C.ordered_product_qty,C.ordered_product_total_price,D.product_name from Users as A NATURAL JOIN Orders as B NATURAL JOIN Order_Details as C NATURAL JOIN Products as D Order By B.date DESC"
  con.query(sql, (err, result) => {
    if (err) {
      console.log(err);
      res.send({ message: 'Error' })
    }
    if (req.params.status === 'placed') {
      result = result.filter((value, index, array) => {
        if (value.Order_Status === 'PLACED')
          return value;
      });
    }
    else if (req.params.status === 'not_placed') {
      result = result.filter((value, index, array) => {
        if (value.Order_Status === 'NOT PLACED')
          return value;
      });
    }
    return res.send(result);
  })
}


const PlacedOrder = async (req, res) => {
  console.log("Placed Order")
  let details = req.body;
  con.beginTransaction();
  let dict = []
  for (let i = 0; i < details.length; i++) {
    const result = HelperUpdate(details, i);
    result.then(function () { }).catch(function () { })
    dict.push(result);
  }
  Promise.all(dict)
    .then(function () {
      con.query(`UPDATE Orders SET Order_Status = "PLACED" WHERE Order_id = '${details[0]["Order_id"]}'`, (err, resutl) => {
        if (err) {
          con.rollback(function () {
            res.send({ message: 'Error' })
          })
        }
        else {
          con.commit()
          res.send({ message: 'Success' })
        }
      })
    })
    .catch(err => {
      con.rollback(function () {
        res.send({ message: 'Error' })
      })
    })


}


const RemoveProduct = async (req, res) => {
  console.log("rngrjg ")
  fs.readdir(product_path, (err, files) => {
    if (err) {
      res.send({ message: 'Error' })
    }
    else {
      try {
        for (let file of files) {
          
          if (file.startsWith(req.params.company_name + '_' + req.params.product_name)) {
            console.log(407,file);
            fs.unlink(path.join(product_path, file), err => {
              if (err) throw err;
              else { console.log("DELETED ", file) }
            });
          }
        }
      }
      catch (err) {
        console.log(err)
        res.send({ message: 'Error' })
      }
    }
  });
  con.query(`DELETE FROM Products WHERE product_id = ${req.params.product_id}`, (err, result) => {
    if (err) {
      console.log(err);
      res.send({ message: 'Error' })
    }
    else {
      res.send({ message: 'Success' })
    }
  })
}


const UpdateProduct = async (req, res) => {
  uploaded_product_files = [];
  console.log("UPDATE PRODUCT")

  uploadProduct(req, res, (err) => {
    if (err) {
      deleteUploadedFile(uploaded_product_files, product_path);
      res.send({ message: "Error" })
    }
    const product_id = req.body.product_id;
    const company_name = req.body.company_name;
    const product_name = req.body.product_name;
    const product_type = req.body.product_type;
    const product_price = req.body.product_price;
    const product_main_cat = req.body.product_main_cat;
    const product_sub_cat = req.body.product_sub_cat;
    const product_des = req.body.product_description;
    const product_total_type = req.body.product_total_type;
    const product_types = req.body.product_types;
    const product_types_qty = req.body.product_types_qty;
    const product_qty = req.body.product_qty;
    let old_images = req.body.old_images;
    console.log(old_images)

    con.beginTransaction(function (err) {
      if (err) {
        deleteUploadedFile(uploaded_product_files, product_path);
        console.log(err)
        con.rollback(function () {
          res.send({ message: 'Error' })
        })
      }
      else {
        con.query(`Delete from Products where product_id = ${product_id}`, (err, result) => {
          if (err) {
            console.log(err);
            deleteUploadedFile(uploaded_product_files, product_path);
            con.rollback(function () {
              res.send({ message: 'Error' })
            })
          }
          else {
            console.log('RECORD DELETED');
            con.query(`SELECT * FROM Products where company_name = '${company_name}' and product_name = '${product_name}'`, (err, result) => {
              if (err) {
                deleteUploadedFile(uploaded_product_files, product_path);
                console.log(err)
                res.send({ message: "Error" })
              }
              else if (result.length >= 1) {
                deleteUploadedFile(uploaded_product_files, product_path);
                res.send({ message: "Duplicate" })
              }
              else if (result.length == 0) {
                con.query(`insert into Products(company_name,product_name,product_type,product_price,product_main_cat,product_sub_cat,product_description) values('${company_name}','${product_name}','${product_type}','${product_price}','${product_main_cat}','${product_sub_cat}','${product_des}')`, (err, result) => {
                  if (err) {
                    console.log(err)
                    deleteUploadedFile(uploaded_product_files, product_path);
                    con.rollback(function () {
                      res.send({ message: 'Error' })
                    })
                  }
                  else {
                    console.log('NEW RECORD INSERTED');

                    let id = result.insertId;
                    let values = []
                    if (product_type === "None") {
                      values.push([id, product_type, "None", product_qty])
                    }
                    else {
                      for (let i = 0; i < product_total_type; i++) {
                        values.push([id, product_type, product_types[i], product_types_qty[i]])
                      }
                    }
                    con.query(`INSERT INTO Types(product_id,product_type,product_type_des,product_qty) values ?`, [values], (err, result) => {
                      if (err) {
                        console.log(err);
                        deleteUploadedFile(uploaded_product_files, product_path);
                        con.rollback(function () {
                          res.send({ message: 'Error' })
                        })
                      }
                      else {
                        console.log('NEW RECORD INSERTED2');
                        let values = []
                        for (let i = 0; i < uploaded_product_files.length; i++) {
                          values.push([id, encodeURIComponent(uploaded_product_files[i])]);
                        }
                        if (old_images) {
                          old_images = (old_images instanceof Array) ? old_images : [old_images]
                          for (let i = 0; i < old_images.length; i++) {
                            let tmp = path.parse(old_images[i]).name.split('_');
                            let originalName = tmp.pop()

                            let newFileName = company_name + "_" + product_name + "_" + Date.now() + "_" + originalName + path.extname(old_images[i]);
                            console.log("NEW : ", newFileName)
                            fs.renameSync(path.join(product_path, `/${old_images[i]}`), path.join(product_path, `/${newFileName}`));
                            values.push([id, encodeURIComponent(newFileName)])
                            console.log(values)
                          }
                        }
                        console.log(values)
                        con.query(`INSERT INTO Product_Images(product_id,img) values ?`, [values], (err, result) => {
                          if (err) {
                            deleteUploadedFile(uploaded_product_files, product_path);
                            console.log(err)
                            con.rollback(function () {
                              res.send({ message: 'Error' })
                            })
                          }
                          else {
                            console.log('NEW RECORD INSERTED3');
                            con.commit()
                            console.log("check 1")
                            // res.send({ message: 'Success' })
                            console.log("check 2")
                          }
                        })
                      }
                    })
                  }
                })
              }
            })
          }
        })
      }

    })

  })
}


const UpdateProductStock = async (req, res) => {
  console.log(req.body);
  const product_id = req.body.product_id[0];
  const product_type = req.body.product_type[0];
  const product_types = req.body.product_types ? req.body.product_types : 'None';
  const product_qty = req.body.product_types_qty ? req.body.product_types_qty : req.body.product_qty;

  console.log(product_id, product_type, product_types, product_qty);
  if (product_type === 'None') {
    con.query(`UPDATE Types SET product_qty = ${product_qty} where product_id = '${product_id}' and product_type = '${product_type}'  and product_type_des = '${product_types}' `, (err, result) => {
      if (err) {
        res.send({message:'Error'})
      }
      else {
        res.send({ message: 'Success' })
      }
    })
  }
  else {
    let dict = [];
    for (let i = 0; i < product_types.length; i++) {
      const result = HelperUpdateStock(product_id, product_type, product_types[i], product_qty[i]);
      result.then(function () { }).catch(function () { })
      dict.push(result);
    }
    Promise.all(dict)
      .then(function () {
        res.send({ message: 'Success' })
      })
      .catch(err => {
        con.rollback(function () {
          res.send({ message: 'Error' })
        })
      })
  }

}

const LogOut = async (req, res) => {
  console.log('grjng')
  res.clearCookie('adminToken');
  res.redirect('/admin');
}

module.exports = {
  SignIn, SignInPage, AddProduct, GetUsers, AddCompany, ChangeUserRequest, OrderDetials, PlacedOrder, RemoveProduct, UpdateProduct, UpdateProductStock,LogOut
}




